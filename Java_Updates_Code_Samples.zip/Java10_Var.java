
public class Java10_Var {
    public static void main(String[] args) {
        var message = "Hello, Java 10!";
        System.out.println(message);
    }
}
