
public class Java5_Enum {
    enum Direction { NORTH, SOUTH, EAST, WEST }

    public static void main(String[] args) {
        Direction d = Direction.NORTH;
        System.out.println(d);
    }
}
