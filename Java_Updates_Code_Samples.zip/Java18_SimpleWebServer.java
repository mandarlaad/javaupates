
// Run from command line (Java 18+)
// Terminal command:
// jwebserver --port 8000

// No code file needed; built-in HTTP server for static files
