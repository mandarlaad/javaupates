
// String Templates is a preview feature in Java 21+
// Example (not yet widely supported):
// String name = "Alice";
// String greeting = STR."Hello \{name}!";
